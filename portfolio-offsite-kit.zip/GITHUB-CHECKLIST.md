# GitHub clean-up — 30 minutes, in this order

1. **Archive the dead repos** (Settings → General → "Archive this repository"): `car-Project`, `sfdx-project`, `Salesforce-Trailhead`.
   Archived repos stay visible but read-only and drop out of the first impression. Delete them instead if you'd rather they vanish.
2. **Profile README**: create a public repo named exactly `amanparate`, tick "Add a README", paste `github-profile/README.md`.
3. **Pin** (profile page → "Customize your pins"): `apex-doctor`, `amanparate.github.io`, and `salesforce-patterns` once it exists.
4. **salesforce-patterns**: create the public repo, unzip `salesforce-patterns/` into it, push. Then add your five samples one at a time —
   each one is a commit with code + test + its `docs/` page filled in. Do not push the repo with empty folders; push when pattern 01 is done.
5. **Apex Doctor**: one small release (a dependency bump, a README refresh, a fix) makes the "last commit" stat current again.
   Add a line to the top of its README: "If Apex Doctor saved you time, a ⭐ helps other developers find it." — 2,000+ installs vs 1 star is a visibility gap, not a quality one.
6. **Profile settings**: bio "Senior Salesforce Developer · 13× certified · author of Apex Doctor", location Pune, website amanparate.github.io, and turn on "Available for hire" if your GitHub plan shows it.
