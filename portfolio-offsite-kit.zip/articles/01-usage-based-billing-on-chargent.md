# Designing usage-based billing on Salesforce with Chargent

*Draft for dev.to / LinkedIn / Medium — edit freely, add the details only you know (volumes, edge cases, what went wrong first).*

---

> **Before publishing, verify these details I inferred from the case study:** the two-job split (metering job → charge job) and the `Ready` state on metering records, the Kafka events named (successful / failed collection), and that re-runs are keyed on the metering record. Replace anything that isn't how you actually built it.


Most Salesforce billing write-ups assume a subscription: a fixed amount, a fixed day, repeat. The customers I bill at Tarana Wireless don't work like that. US customers pay for what they actually use each month, and until last year "what they used" was a number finance worked out by hand, turned into an invoice by hand, and collected separately — by hand. Every new customer made the month-end a little slower and a little riskier, in the one place where a wrong number costs the most.

This is how we rebuilt it on Salesforce and Chargent, and the three decisions that mattered more than any line of Apex.

## The shape of the problem

Three things had to be true at the same time:

1. The charge for a month is computed from measured usage, not from a plan.
2. The customer authorises payment once, and every subsequent month collects automatically.
3. Finance can see and trust every number before and after money moves.

Anything that satisfied two of the three was going to recreate the manual work somewhere else.

## Decision 1: Chargent over custom payment code

The first instinct on the platform is always "we could build this". For payments, that instinct is wrong. Card data, tokenisation and PCI scope belong with a payment gateway, not in a custom object. Chargent gave us the stored payment mandate, the gateway integration and the retry plumbing; we kept the part that is actually *our* business logic — usage → invoice.

That line is the whole design. If you find yourself writing code that stores or moves card details, stop and buy that part.

## Decision 2: metering is separate from charging

The month's usage is computed first, as its own record, and it is reviewable. Only then does the charge run read it. This sounds like bureaucracy; it is the difference between "a bad reading becomes a bad invoice that finance catches" and "a bad reading becomes a bad charge on a customer's card that we refund and apologise for".

Practically: a scheduled Apex job calculates usage per customer per month into a metering record. A second, independent batch job generates invoices from metering records in a `Ready` state and asks Chargent to collect against the stored mandate. Nothing charges off a number a human hasn't been able to look at.

## Decision 3: Salesforce owns the customer and the billing schedule

Billing data has to reach finance, and finance doesn't live in Salesforce. The temptation is to let every downstream system pull what it needs. We did the opposite: Salesforce is the system of record for the customer and the billing schedule, and downstream consumers get the *results*.

- **Boomi** for orchestrated, auditable sync of invoices and customer records into NetSuite (still being rolled out as I write this).
- **Kafka** for the events that can't wait for a batch window — a successful collection, a failed one.

When ownership per record is unambiguous, "which number is right?" stops being a question anyone has to ask.

## Governor limits as a design input, not a bug

Invoice generation and charge runs are batch Apex, sized from day one around the limits: how many customers per execute, what happens when a gateway call is slow, what state a half-finished run leaves behind. The job is re-runnable for the same period without double-charging, because the metering record carries the state, not the job.

## What it changed

- About **$3M** of customer billing went through auto-invoicing last quarter.
- Manual finance effort on billing dropped by roughly **90%**.
- Collection is automatic, monthly, against a mandate the customer set up once in the portal.

## What I'd tell someone starting the same build

Separate the measurement from the money. Buy the part that touches cards. Decide who owns each record before you write the first integration. And build the batch job as if it will be re-run on a Friday evening after a partial failure — because it will.

*Aman Parate is a Senior Salesforce Developer in Pune and the author of [Apex Doctor](https://github.com/amanparate/apex-doctor). More case studies at [amanparate.github.io](https://amanparate.github.io).*
