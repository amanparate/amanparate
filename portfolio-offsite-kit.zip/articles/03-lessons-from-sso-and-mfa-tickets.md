# What two years of SSO and MFA tickets at Salesforce taught me about integration design

*Draft — swap in two or three real (anonymised) tickets; the pattern matters more than the product names.*

> **Before publishing, verify:** the ticket categories and the lessons are drawn from your Salesforce-era experience summary (SSO, MFA, Flows, async Apex hitting limits, REST/SOAP/Bulk/Platform Events/CDC). Replace my illustrative examples with ones you actually handled.

---

From 2023 to 2024 I worked as a Service Cloud Engineer at Salesforce, on the end of the platform nobody writes conference talks about: UK and US customers whose single sign-on had stopped working, whose MFA rollout had locked out the wrong people, whose triggers hit limits on the one day of the month that mattered. Hundreds of orgs, none of them built the same way.

I went in thinking it was a support job. It turned out to be the best architecture education I could have had, because I got to see the same designs fail in a hundred different ways. Four lessons stuck, and I've used every one of them since on the Salesforce estate I now own at Tarana Wireless.

## 1. Identity is an integration, and it breaks like one

An SSO failure is almost never "SSO is broken". It is a certificate that expired on one side, a clock skew between the identity provider and Salesforce, an attribute that one admin renamed, or a user that exists in one directory and not the other. Every one of those is an integration-boundary problem: two systems with their own view of the truth and nobody who owns the contract between them.

When I later built SAML SSO from Salesforce into LearnUpon, the first artefact wasn't code. It was a one-page contract: which system is the identity provider, which attributes cross the boundary, who rotates the certificate and when, and what the user sees when it fails. Six to ten new users a day have logged in through it since, and the on-call question "whose problem is this?" has an answer written down.

## 2. Limits aren't edge cases; they're the normal case at scale

A surprising share of "my trigger stopped working" tickets were triggers that had worked for two years and then met a data load, a nightly job, or a growing customer base. Governor limits don't appear at the edge of the system; they appear exactly where the business succeeds.

That turned into a rule I still apply: bulkify first, and design async work (Queueable, Batch, Platform Events) so that a partial failure leaves a resumable state rather than a half-written one. Usage-based billing at Tarana runs as batch Apex that can be re-run for the same period without double-charging — because I'd read too many logs from jobs that couldn't.

## 3. Failures must land somewhere a human looks

The worst tickets were the quiet ones: a Change Data Capture subscriber that had silently stopped, an outbound message that had been failing for weeks, a Flow fault path that wrote to a debug log nobody opened. The customer found out from their own customers.

So: integration failures become records — a work item, a case, something with an owner and an age — not log lines. Boomi for orchestrated sync gives you that audit trail by design; for Kafka and EDI flows at Tarana we built it in deliberately. If a sync fails at 2 a.m., somebody's queue has an item in it at 9.

## 4. Most "technical" problems are process problems in disguise

The MFA rollouts that went badly weren't badly configured. They were rolled out to people who hadn't been told, by admins who hadn't been given a way to exempt the integration users. The fix was rarely a setting; it was a sequence.

That is the lens I bring to every design now: find where the code meets the business process, because that's where it will fail. The portal onboarding journey I built at Tarana supports twenty to thirty self-registrations a day with almost no manual steps — not because the Flows are clever, but because we mapped the process (including the sign-ups that *shouldn't* get through, like non-company email domains) before we built anything.

## The short version

Treat identity as an integration. Treat limits as the normal case. Make failures visible to a person. And look for the process problem hiding inside the technical one. Two years of other people's broken orgs is a hard way to learn those four things — I'm glad I don't have to learn them again.

*Aman Parate is a Senior Salesforce Developer in Pune, India, and the author of [Apex Doctor](https://github.com/amanparate/apex-doctor), a VS Code extension for diagnosing Apex debug logs. Case studies at [amanparate.github.io](https://amanparate.github.io).*
