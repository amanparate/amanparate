# How Apex Doctor reads a debug log (and why it does it offline)

*Draft — add a real (anonymised) log snippet and one screenshot per section; the Apex Doctor repo already has both.*

---

> **Before publishing, verify against your actual code:** how events are paired into the tree, how the explain plan is attached to a query node, how heap is attributed, how the async tracer matches job IDs, and the exact privacy guarantees of the AI step. I described the mechanics the way such a parser typically works — your implementation is the source of truth.


A Salesforce debug log is a stack trace, a profiler, a SOQL audit and a governor-limit report all interleaved into one text file that nobody designed to be read by a person. For a long time my team's answer to "why did this transaction fail?" was: open the log, scroll, search for `LIMIT_USAGE`, scroll more, give up, add more `System.debug`. About thirty minutes, every time.

Apex Doctor started as a parser for exactly that file. This is how it works under the hood, and why the important parts run with no network at all.

## Step 1: the log is a tree, not a list

Every line in a debug log has a timestamp, an event type and a payload. `CODE_UNIT_STARTED` / `CODE_UNIT_FINISHED`, `METHOD_ENTRY` / `METHOD_EXIT`, `SOQL_EXECUTE_BEGIN` / `SOQL_EXECUTE_END` are pairs. Pair them up and the flat file becomes a call tree with durations on every node.

Once you have the tree, most "diagnostics" are just queries over it:

- **SOQL in a loop** — a `SOQL_EXECUTE_BEGIN` node whose parent method appears N times under the same ancestor with the same query text.
- **Full-table scan** — a query node whose `SOQL_EXECUTE_EXPLAIN` sibling reports a table scan plan.
- **Trigger order** — the sequence of `CODE_UNIT_STARTED` nodes of type trigger under one DML node, which is the actual order of execution for that transaction, not the one in the docs.

None of this needs a model. It needs a correct parser and a handful of well-named rules.

## Step 2: self-time, not total time

The number that finds the slow method is *self-time*: a method's duration minus the duration of everything it called. A method with a huge total time but tiny self-time is just a caller; the problem is further down. Chrome DevTools has done this for years; debug logs had nothing like it. Apex Doctor computes self-time for every node and sorts by it — that single view usually points at the offending query or loop in seconds.

Heap works the same way: `HEAP_ALLOCATE` events attributed to the node that was open when they fired.

## Step 3: following work across logs

`@future`, Queueable and Batch jobs run in separate transactions, so a failure that started in one request shows up in a different log. The async tracer links them: the job ID from the enqueue in one log is matched to the `CODE_UNIT_STARTED` of the job in another, so you can follow a chain end to end.

## Why offline is a feature

Debug logs contain customer data — record IDs, names, sometimes whole email bodies. Shipping them to a third-party API to "explain the error" is not something I'd want a teammate to do by accident. So the deterministic engine runs entirely on the developer's machine, and the AI root-cause step is opt-in and built around that constraint:

- Only a distilled, PII-safe summary of the findings leaves the machine, never the raw log.
- Five providers are supported, including the **Salesforce Einstein Trust Layer**, so the analysis can run inside the org's own trust boundary.
- API keys live in VS Code's encrypted SecretStorage, not in settings files.

The AI is good at writing the explanation; the parser is what finds the problem.

## What the extension does with the tree

Everything else is views over the same structure: the timeline, the slowest-methods table, SOQL/DML/limit counters, the in-gutter test coverage overlay, the Query Plan integration for selectivity problems, and "Suggest Fix", which proposes a refactor with a diff preview for the patterns it recognises (SOQL in a loop being the obvious one).

## What building it taught me

- Parsing is the product. Every feature people liked came from the tree being right.
- Developers trust a tool that works with no network far more than one that promises to.
- Shipping to the VS Code Marketplace and Open VSX turns "a script I use" into something 2,000+ people install — and into a support queue, which is its own education.

*Apex Doctor is open source (MIT): [github.com/amanparate/apex-doctor](https://github.com/amanparate/apex-doctor). If it saves you a Friday afternoon, a ⭐ helps other developers find it.*
