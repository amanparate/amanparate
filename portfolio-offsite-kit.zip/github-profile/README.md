# Hi, I'm Aman 👋

**Senior Salesforce Developer** · Pune, India · 13× Salesforce Certified · Triple Star Ranger

I build inside Salesforce orgs for a living — Experience Cloud portals, usage-based billing on Chargent, and the Boomi / Kafka / EDI integrations that keep Salesforce in step with finance and logistics — and I build developer tools for the Salesforce community on the side.

- 🩺 **[Apex Doctor](https://github.com/amanparate/apex-doctor)** — a VS Code extension that diagnoses Apex debug logs in seconds. CPU & heap profiler with self-time attribution, cross-log async tracer, order-of-execution map, SOQL-in-loop bulkification, AI root-cause analysis across five providers (incl. the Einstein Trust Layer, so data never leaves the org). 2,000+ installs on the VS Code Marketplace and Open VSX.
- 🧩 **[salesforce-patterns](https://github.com/amanparate/salesforce-patterns)** — small, tested Apex and LWC samples showing how I actually structure production code: trigger handler, Queueable chains with retry, callouts with mocks, LWC with Jest.
- 🌐 **[amanparate.github.io](https://amanparate.github.io)** — case studies with architecture diagrams, and the story behind them.

**Currently:** EDI integrations with 3PL and partner systems; Boomi flows syncing finance data with NetSuite; exploring Agentforce and Data Cloud (certified in both).

**How I work:** design the system, not the ticket · bulkify, then automate · integration boundaries are contracts · if it hurt to debug, build the tool.

📫 [amanparatesfdc@gmail.com](mailto:amanparatesfdc@gmail.com) · [LinkedIn](https://www.linkedin.com/in/amanparate/) · [Trailblazer profile](https://www.salesforce.com/trailblazer/amanparate)

<!--
To make this your GitHub profile page:
1. Create a new PUBLIC repository named exactly  amanparate  (same as your username).
2. Tick "Add a README file", then replace its contents with this file.
3. Commit — GitHub shows it at the top of github.com/amanparate.
Remove the salesforce-patterns line until that repo exists.
-->
