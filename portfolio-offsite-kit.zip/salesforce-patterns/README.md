# salesforce-patterns

Small, tested Apex and LWC samples showing how I structure production Salesforce code.
Each pattern is one folder under `docs/` (the write-up) plus its metadata under `force-app/`.
Every class ships with a test class; every LWC ships with a Jest test.

| Pattern | What it demonstrates | Status |
|---|---|---|
| [01 · Trigger handler](docs/01-trigger-handler.md) | One trigger per object, handler class, bulk-safe, recursion guard, bypass for data loads | ☐ |
| [02 · Queueable chain with retry](docs/02-queueable-chain.md) | Chained async work, idempotent steps, bounded retries, failure surfaced as a record | ☐ |
| [03 · Callout with mock](docs/03-callout-with-mock.md) | Named Credential, typed request/response wrappers, `HttpCalloutMock`, error mapping | ☐ |
| [04 · LWC with Jest](docs/04-lwc-with-jest.md) | Wire + imperative Apex, loading/error states, accessibility, Jest coverage | ☐ |
| [05 · Scheduled billing run](docs/05-scheduled-batch.md) | Schedulable → Batchable, governor-limit-aware chunking, run log, re-runnable | ☐ |

## Why these five

They are the five things I get asked about in every Salesforce design review:
how triggers stay bulk-safe, how async work fails safely, how integrations are tested
without hitting a real endpoint, how UI code is tested at all, and how a scheduled job
is made re-runnable. The samples are deliberately small — the point is the decisions,
which are written up in each `docs/` page.

## Running the tests

```bash
sf org create scratch -f config/project-scratch-def.json -a patterns -d
sf project deploy start
sf apex run test --test-level RunLocalTests --code-coverage --result-format human
npm install && npm test          # LWC Jest tests
```

## Conventions

- Apex: `with sharing` by default; FLS/CRUD checked via `Security.stripInaccessible`; no SOQL/DML in loops; one trigger per object.
- Tests: `@TestSetup` data factories, no `SeeAllData`, assert behaviour not coverage.
- Naming: `AccountTriggerHandler`, `AccountTriggerHandlerTest`, `InvoiceCalloutService`, `InvoiceCalloutServiceTest`.
