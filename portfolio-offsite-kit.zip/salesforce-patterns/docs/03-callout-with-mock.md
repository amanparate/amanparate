# Callout with mock

**Files:** `InvoiceCalloutService (+Test, +Mock)`

## What it does
A typed callout through a Named Credential with request/response wrapper classes, timeouts, and status-code mapping to a small exception hierarchy.

## Design decisions
<!-- Write these in your own words — this is what a reviewer reads first. Answer: -->
Why Named Credentials; why wrapper classes over Map<String,Object>; how non-2xx is handled; how the mock asserts the request body; what is logged and what is not (PII).

## How to run it
```bash
sf apex run test --tests InvoiceCalloutServiceTest --code-coverage
```

## What I'd change at scale
<!-- One or two sentences on what breaks first when volume grows, and what you'd do about it. -->
