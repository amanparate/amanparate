# LWC with Jest

**Files:** `caseList (+ Apex controller + Jest)`

## What it does
A component that wires a list, handles loading / empty / error states, is keyboard accessible, and is covered by Jest tests that mock the Apex adapter.

## Design decisions
<!-- Write these in your own words — this is what a reviewer reads first. Answer: -->
Why wire vs imperative here; how errors are surfaced to the user; what the Jest tests assert (render states, event payloads); accessibility checks.

## How to run it
```bash
sf apex run test --tests caseListTest --code-coverage
```

## What I'd change at scale
<!-- One or two sentences on what breaks first when volume grows, and what you'd do about it. -->
