# Queueable chain with retry

**Files:** `InvoiceSyncQueueable (+Test)`

## What it does
A chain of Queueable steps that is idempotent and bounded. Each step records progress on a custom object; retries are capped; terminal failure creates a work item.

## Design decisions
<!-- Write these in your own words — this is what a reviewer reads first. Answer: -->
Why Queueable over @future; how idempotency is guaranteed (external id / upsert); what the retry policy is; how failures become visible to a human; how the test covers the retry path.

## How to run it
```bash
sf apex run test --tests InvoiceSyncQueueableTest --code-coverage
```

## What I'd change at scale
<!-- One or two sentences on what breaks first when volume grows, and what you'd do about it. -->
