# Scheduled billing run

**Files:** `BillingRunScheduler + BillingRunBatch (+Test)`

## What it does
A Schedulable that starts a Batchable, sized for governor limits, writing a run log record and safe to re-run for the same period without double-charging.

## Design decisions
<!-- Write these in your own words — this is what a reviewer reads first. Answer: -->
Why metering is separated from charging; how re-runs are made safe; how the batch size was chosen; what the run log captures; how the test covers partial failure.

## How to run it
```bash
sf apex run test --tests BillingRunSchedulerTest --code-coverage
```

## What I'd change at scale
<!-- One or two sentences on what breaks first when volume grows, and what you'd do about it. -->
