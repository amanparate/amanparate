# Trigger handler

**Files:** `AccountTrigger + AccountTriggerHandler (+Test)`

## What it does
One trigger per object delegating to a handler. Bulk-safe collections, static recursion guard, a bypass flag for data loads, and a before/after split.

## Design decisions
<!-- Write these in your own words — this is what a reviewer reads first. Answer: -->
Why one trigger per object; why the guard is per-context not global; what the bypass is for and who may use it; how the test proves bulk behaviour (200 records, assert limits).

## How to run it
```bash
sf apex run test --tests AccountTriggerTest --code-coverage
```

## What I'd change at scale
<!-- One or two sentences on what breaks first when volume grows, and what you'd do about it. -->
